package com.heady.sat.util;

/**
 * Created by admin_vserv on 5/19/2018.
 */

public class Constants {

    public interface DebugTags {
        String TAG = "heady";
        boolean enable_debug_log = true;
    }


    public interface Urls {
        String BASE_URL = "https://stark-spire-93433.herokuapp.com/json";
    }

    public interface SharedPrefManager{
        String dataManagerPref = "Data_Pref";
    }

    public interface key{
        String ecom_data = "ECOM_DATA";
    }
}
