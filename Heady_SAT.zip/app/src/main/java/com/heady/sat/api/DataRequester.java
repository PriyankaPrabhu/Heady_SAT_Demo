package com.heady.sat.api;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;
import android.util.Log;

import com.heady.sat.network.IOManager;
import com.heady.sat.util.Constants;

/**
 * Created by admin_vserv on 5/19/2018.
 */

public class DataRequester {

    public void requestData(Context context)
    {
        try
        {
            String jsonData = new IOManager().execute(Constants.Urls.BASE_URL).get();

            if(jsonData != null && !TextUtils.isEmpty(jsonData))
            {
                SharedPreferences dataPref = context.getSharedPreferences(Constants.SharedPrefManager.dataManagerPref, 0);
                dataPref.edit().putString(Constants.key.ecom_data, jsonData).commit();
            }
        }
        catch (Exception ex)
        {

        }
    }
}
